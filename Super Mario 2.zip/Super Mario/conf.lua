function love.conf(t)
    t.window.title = "Mini Mario Prototype"
    t.window.width = 960
    t.window.height = 540
end
